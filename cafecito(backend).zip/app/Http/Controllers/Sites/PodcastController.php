<?php 
	
	namespace App\Http\Controllers\Sites;

	use App\Model\Podcast;

	class PodcastController extends Controller
	{
		public function index()
		{
			$podcasts = Podcast::all();
		}
	}

?>